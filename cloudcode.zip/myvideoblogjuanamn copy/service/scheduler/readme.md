﻿# Scheduled Scripts

The 'scheduler' folder contains scripts that are run on a regular interval. You can create and configure these jobs from the Windows Azure Portal, and then edit the scripts directly from this repository.

## More Information

For more information see the [documentation](http://go.microsoft.com/fwlink/?LinkID=307138&clcid=0x409).