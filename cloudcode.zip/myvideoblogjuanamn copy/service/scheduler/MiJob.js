function MiJob() {
    console.warn("You are running an empty scheduled job. Update the script for job 'MiJob' or disable the job.");
    
    console.log("yo pase por aqui");
        
    mssql.query("delete from elementos where edad > 17",{
        success: function(result){
            console.log("Hemos podido borrar");
        }, error: function(error){
            console.log("Error -> "+ error);
        }
    });
    
    
}