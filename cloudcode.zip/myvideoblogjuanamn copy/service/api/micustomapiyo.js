/**
 * Created by byjuanmn on 22/02/16.
 */


exports.get = function(request, response) {


    console.log('este es un ejemplo de custom Api');
    response.send(statusCodes.OK, { message : 'Hello World!' });
};