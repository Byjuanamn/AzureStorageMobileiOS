

exports.get = function(request, response) {
    response.send(statusCodes.OK, { message : '*********** EJEMPLO DE API ***********' });
};