function del(id, user, request) {


    console.log("Estoy borrando un registro " + id );
    console.log("Actualizado desde WebStorm");

    request.execute();

}